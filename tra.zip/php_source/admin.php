<?php
require_once 'config.php';
if (!isset($_SESSION['username']) || $_SESSION['username'] !== 'admin') {
    header('Location: index.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="vi" class="dark">
<head>
    <meta charset="UTF-8">
    <title>Admin Panel</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = { darkMode: 'class', theme: { extend: { colors: { bg: '#05070c', panel: '#0c1220', border: '#1f2f4a' } } } }
    </script>
    <style>body { background-color: #05070c; color: white; }</style>
</head>
<body class="p-4">
    <div class="flex justify-between items-center mb-6 border-b border-border pb-4">
        <h1 class="text-xl font-bold text-yellow">ADMIN PANEL</h1>
        <a href="index.php" class="bg-panel border border-border px-4 py-2 rounded hover:bg-white/5">← Về sàn</a>
    </div>
    
    <div class="grid gap-6 max-w-4xl mx-auto">
        <div class="bg-panel border border-border rounded-xl p-6">
            <h2 class="text-lg font-bold mb-4 text-blue">Quản lý User</h2>
            <table class="w-full text-sm text-left">
                <thead class="text-gray-500 border-b border-border">
                    <tr><th>Username</th><th>Số dư</th><th>Role</th></tr>
                </thead>
                <tbody>
                    <?php
                    $users = $db->query("SELECT * FROM users")->fetchAll(PDO::FETCH_ASSOC);
                    foreach($users as $u): ?>
                    <tr class="border-b border-border/50">
                        <td class="py-3 font-bold text-blue"><?= $u['username'] ?></td>
                        <td class="py-3 text-yellow"><?= number_format($u['balance']) ?></td>
                        <td class="py-3"><?= $u['role'] ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>
