<?php
require_once 'config.php';

$action = $_GET['action'] ?? '';
$user = getCurrentUser($db);

if (!$user && $action !== 'login') {
    jsonResponse(['success' => false, 'message' => 'Unauthorized']);
}

// Session Logic
$now = time();
$current_minute = floor($now / 60);
$session_id = 123 + $current_minute - floor(1704067200000 / 60000); // Just an offset
// Simplify: Start from 123 relative to when I wrote this code approx
$START_TIME = 1736899200; // Approx timestamp
$session_id = 123 + floor(($now - $START_TIME) / 60);
$time_left = 60 - ($now % 60);

if ($action === 'status') {
    // Check for finished bets
    $win_amount = 0;
    
    // Logic: If previous session finished, check bets for that session
    // In real app, a cron job or worker handles this. Here we check on status poll.
    $last_session = $session_id - 1;
    
    // Determine result of last session (Deterministic based on ID for demo)
    // In real app, admin sets this or random.
    // We'll use a simple hash for random result if not forced.
    $last_result = ($last_session % 2 == 0) ? 'TĂNG' : 'GIẢM'; 
    
    // Check if we have pending bets for last session
    $stmt = $db->prepare("SELECT * FROM bets WHERE username = ? AND session_id = ? AND status = 'PENDING'");
    $stmt->execute([$user['username'], $last_session]);
    $bets = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    foreach($bets as $bet) {
        $is_win = $bet['type'] === $last_result;
        $win = $is_win ? $bet['amount'] * 1.9 : 0;
        
        $db->prepare("UPDATE bets SET status = ?, win_amount = ? WHERE id = ?")
           ->execute([$is_win ? 'WIN' : 'LOSE', $win, $bet['id']]);
           
        if ($is_win) {
            $db->prepare("UPDATE users SET balance = balance + ? WHERE username = ?")
               ->execute([$win, $user['username']]);
            $win_amount += $win;
        }
    }
    
    // Get History
    $history = [];
    for($i=1; $i<=5; $i++) {
        $sid = $session_id - $i;
        $res = ($sid % 2 == 0) ? 'TĂNG' : 'GIẢM';
        $history[] = ['session_id' => $sid, 'result' => $res];
    }
    
    // Get fresh user data
    $user = getCurrentUser($db);

    jsonResponse([
        'session_id' => $session_id,
        'time_left' => $time_left,
        'balance' => $user['balance'],
        'history' => $history,
        'win_amount' => $win_amount
    ]);
}

if ($action === 'bet') {
    $input = json_decode(file_get_contents('php://input'), true);
    $amount = $input['amount'];
    $type = $input['type'];
    
    if ($user['balance'] < $amount) {
        jsonResponse(['success' => false, 'message' => 'Số dư không đủ']);
    }
    
    $db->beginTransaction();
    try {
        $db->prepare("UPDATE users SET balance = balance - ? WHERE username = ?")
           ->execute([$amount, $user['username']]);
           
        $db->prepare("INSERT INTO bets (session_id, username, type, amount, timestamp) VALUES (?, ?, ?, ?, ?)")
           ->execute([$session_id, $user['username'], $type, $amount, $now]);
           
        $db->commit();
        jsonResponse(['success' => true]);
    } catch (Exception $e) {
        $db->rollBack();
        jsonResponse(['success' => false, 'message' => 'Lỗi hệ thống']);
    }
}
?>