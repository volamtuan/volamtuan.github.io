import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useTradingStore } from '../store/useTradingStore';
import { clsx } from 'clsx';

export const WalletPage: React.FC = () => {
  const navigate = useNavigate();
  const { currentUser: user, requestTransaction, transactions } = useTradingStore();
  const [amount, setAmount] = useState('');

  if (!user) return null;

  const handleRequest = (type: 'DEPOSIT' | 'WITHDRAW') => {
    const val = parseInt(amount.replace(/,/g, ''));
    if (!val || val <= 0) return alert('Vui lòng nhập số tiền hợp lệ');
    if (type === 'WITHDRAW' && val > user.balance) return alert('Số dư không đủ');
    
    requestTransaction(type, val);
    setAmount('');
  };

  return (
    <div className="min-h-screen bg-bg text-white font-sans p-4">
      <div className="flex justify-between items-center mb-6 border-b border-border pb-4">
        <h1 className="text-xl font-bold text-yellow">VÍ CỦA TÔI</h1>
        <button 
          onClick={() => navigate('/')}
          className="bg-panel border border-border px-4 py-2 rounded hover:bg-white/5"
        >
          ← Về sàn giao dịch
        </button>
      </div>

      <div className="max-w-md mx-auto">
        <div className="bg-panel border border-border rounded-xl p-6 mb-6 text-center">
          <div className="text-gray-400 mb-2">Số dư hiện tại</div>
          <div className="text-3xl font-bold text-yellow">{user.balance.toLocaleString()} đ</div>
        </div>

        <div className="bg-panel border border-border rounded-xl p-6 mb-6">
          <h3 className="font-bold mb-4">Tạo yêu cầu</h3>
          <input
            type="number"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            placeholder="Nhập số tiền..."
            className="w-full bg-bg border border-border rounded-lg p-3 text-white mb-4 focus:outline-none focus:border-blue"
          />
          <div className="grid grid-cols-2 gap-4">
            <button
              onClick={() => handleRequest('DEPOSIT')}
              className="bg-green text-black font-bold py-3 rounded-lg hover:bg-green/90"
            >
              NẠP TIỀN
            </button>
            <button
              onClick={() => handleRequest('WITHDRAW')}
              className="bg-red text-white font-bold py-3 rounded-lg hover:bg-red/90"
            >
              RÚT TIỀN
            </button>
          </div>
        </div>

        <div className="bg-panel border border-border rounded-xl p-6">
          <h3 className="font-bold mb-4">Lịch sử giao dịch</h3>
          <div className="flex flex-col gap-3">
            {transactions.length === 0 ? (
              <div className="text-center text-gray-500 text-sm">Chưa có giao dịch nào</div>
            ) : (
              transactions.map((tx) => (
                <div key={tx.id} className="flex justify-between items-center border-b border-border pb-2 last:border-0">
                  <div>
                    <div className={clsx("font-bold text-sm", tx.type === 'DEPOSIT' ? 'text-green' : 'text-red')}>
                      {tx.type === 'DEPOSIT' ? 'Nạp tiền' : 'Rút tiền'}
                    </div>
                    <div className="text-xs text-gray-500">{new Date(tx.timestamp).toLocaleString()}</div>
                  </div>
                  <div className="text-right">
                    <div className="font-bold">{tx.amount.toLocaleString()}</div>
                    <div className={clsx(
                      "text-[10px] font-bold px-2 py-0.5 rounded inline-block mt-1",
                      tx.status === 'APPROVED' ? 'bg-green/20 text-green' :
                      tx.status === 'REJECTED' ? 'bg-red/20 text-red' : 'bg-yellow/20 text-yellow'
                    )}>
                      {tx.status === 'APPROVED' ? 'Thành công' : tx.status === 'REJECTED' ? 'Từ chối' : 'Đang chờ'}
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
