import React from 'react';
import { useTradingStore } from '../../store/useTradingStore';

export const BetConfirmation: React.FC = () => {
  const { pendingBet, cancelPendingBet, confirmBet } = useTradingStore();

  if (!pendingBet) return null;

  return (
    <div className="fixed inset-0 bg-black/85 flex items-center justify-center z-[2000] animate-in fade-in duration-200">
      <div className="bg-panel p-5 rounded-2xl w-[85%] max-w-[320px] text-center border border-border shadow-2xl scale-in-center">
        <h3 className="text-white font-bold text-lg mb-4">XÁC NHẬN LỆNH</h3>
        
        <p className="text-gray-300 mb-6">
          Lệnh <span className={pendingBet.type === 'TĂNG' ? 'text-green font-bold' : 'text-red font-bold'}>{pendingBet.type}</span>: 
          <br/>
          <span className="text-yellow text-xl font-bold">{pendingBet.amount.toLocaleString()}đ</span>
        </p>

        <button 
          onClick={confirmBet}
          className="w-full bg-blue text-white py-3 rounded-xl font-bold mb-3 hover:bg-blue/90 active:scale-95 transition-all"
        >
          XÁC NHẬN
        </button>
        
        <button 
          onClick={cancelPendingBet}
          className="w-full bg-[#333] text-white py-3 rounded-xl font-bold hover:bg-[#444] active:scale-95 transition-all"
        >
          HUỶ
        </button>
      </div>
    </div>
  );
};
