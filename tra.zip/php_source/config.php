<?php
session_start();

// Database Connection (SQLite for portability, easy to switch to MySQL)
try {
    $db = new PDO('sqlite:database.sqlite');
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // Create Tables if not exist
    $db->exec("CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE,
        password TEXT,
        balance REAL DEFAULT 0,
        role TEXT DEFAULT 'user',
        is_locked INTEGER DEFAULT 0
    )");
    
    $db->exec("CREATE TABLE IF NOT EXISTS sessions (
        id INTEGER PRIMARY KEY,
        result TEXT,
        timestamp INTEGER
    )");
    
    $db->exec("CREATE TABLE IF NOT EXISTS bets (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        session_id INTEGER,
        username TEXT,
        type TEXT,
        amount REAL,
        win_amount REAL DEFAULT 0,
        status TEXT DEFAULT 'PENDING',
        timestamp INTEGER
    )");

    // Seed Admin if not exists
    $stmt = $db->prepare("SELECT COUNT(*) FROM users WHERE username = 'admin'");
    $stmt->execute();
    if ($stmt->fetchColumn() == 0) {
        $pass = password_hash('123', PASSWORD_DEFAULT);
        $db->exec("INSERT INTO users (username, password, balance, role) VALUES ('admin', '$pass', 1000000000, 'admin')");
        $db->exec("INSERT INTO users (username, password, balance, role) VALUES ('demo123', '$pass', 100000000, 'user')");
    }

} catch(PDOException $e) {
    die("DB Error: " . $e->getMessage());
}

// Helper Functions
function getCurrentUser($db) {
    if (!isset($_SESSION['username'])) return null;
    $stmt = $db->prepare("SELECT * FROM users WHERE username = ?");
    $stmt->execute([$_SESSION['username']]);
    return $stmt->fetch(PDO::FETCH_ASSOC);
}

function jsonResponse($data) {
    header('Content-Type: application/json');
    echo json_encode($data);
    exit;
}
?>