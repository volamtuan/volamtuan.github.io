import React, { useEffect, useRef } from 'react';

declare global {
  interface Window {
    TradingView: any;
  }
}

export const Chart: React.FC = () => {
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const script = document.createElement('script');
    script.src = 'https://s3.tradingview.com/tv.js';
    script.async = true;
    script.onload = () => {
      if (window.TradingView && containerRef.current) {
        new window.TradingView.widget({
          container_id: containerRef.current.id,
          autosize: true,
          symbol: "BINANCE:BTCUSDT",
          interval: "1",
          theme: "dark",
          locale: "vi",
          hide_top_toolbar: true,
          hide_legend: true,
          save_image: false,
        });
      }
    };
    document.head.appendChild(script);

    return () => {
      // Cleanup if needed, though TV widget is tricky to remove cleanly without reloading
    };
  }, []);

  return (
    <div className="flex-1 bg-black border-b border-[#1a2233] relative overflow-hidden min-h-[300px]">
      <div id="tvchart" ref={containerRef} className="w-full h-full absolute inset-0" />
    </div>
  );
};
