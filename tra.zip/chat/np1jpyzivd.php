<?php
include 'config.php';
session_start();

// --- Rate Limit ---
if(!isset($_SESSION['requests'])) {
    $_SESSION['requests'] = 0;
    $_SESSION['start_time'] = time();
}

$_SESSION['requests']++;
if(time() - $_SESSION['start_time'] < 1) { 
    if($_SESSION['requests'] > 10){
        die("Quá nhiều request, thử lại sau!");
    }
} else {
    $_SESSION['requests'] = 1;
    $_SESSION['start_time'] = time();
}

$msg = "";

// 1. XỬ LÝ ĐĂNG NHẬP / ĐĂNG KÝ
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? 'login';
    $u = trim($_POST['u'] ?? '');
    $p = $_POST['p'] ?? '';

    if ($action === 'login') {
        $stmt = $db->prepare("SELECT * FROM users WHERE username = ?");
        $stmt->execute([$u]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($user && password_verify($p, $user['password'])) {
            $_SESSION['uid'] = $user['id'];
            if (isset($_POST['remember'])) {
                setcookie('remember_user', $u, time() + 86400 * 30, '/');
                setcookie('remember_pass', base64_encode($p), time() + 86400 * 30, '/');
            } else {
                setcookie('remember_user', '', time() - 3600, '/');
                setcookie('remember_pass', '', time() - 3600, '/');
            }
            header("Location: /trade");
            exit;
        } else {
            $msg = "❌ Sai tài khoản hoặc mật khẩu!";
        }
    }

    if ($action === 'reg') {
        $fullname = trim($_POST['fullname'] ?? '');
        $phone = trim($_POST['phone'] ?? '');
        $p2 = $_POST['p2'] ?? '';

        if (strlen($p) < 6) {
            $msg = "❌ Mật khẩu phải từ 6 ký tự trở lên!";
        } elseif ($p !== $p2) {
            $msg = "❌ Mật khẩu không khớp!";
        } else {
            $hash = password_hash($p, PASSWORD_DEFAULT);
            try {
                $stmt = $db->prepare("INSERT INTO users (username, password, fullname, phone) VALUES (?,?,?,?)");
                $stmt->execute([$u, $hash, $fullname, $phone]);
                $msg = "✅ Đăng ký thành công! Hãy đăng nhập.";
            } catch (Exception $e) {
                $msg = "❌ Tên đăng nhập đã tồn tại!";
            }
        }
    }
}

$remember_user = $_COOKIE['remember_user'] ?? '';
$remember_pass = isset($_COOKIE['remember_pass']) ? base64_decode($_COOKIE['remember_pass']) : '';

header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Pragma: no-cache");

if (isset($_SESSION['uid'])) {
    header("Location: /trade");
    exit;
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="UTF-8">
<title>Đăng nhập - MYCSINGTRADE</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
    body {
        font-family: -apple-system, sans-serif;
        background: linear-gradient(180deg, #1a1a1a 0%, #76b852 100%);
        background-attachment: fixed;
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        min-height: 100vh;
        margin: 0;
    }
    .header-logo {
        text-align: center;
        margin-bottom: 30px;
    }
    .header-logo img {
        width: 120px;
        margin-bottom: 10px;
    }
    .header-logo h1 {
        color: #fff;
        font-size: 24px;
        margin: 0;
        letter-spacing: 1px;
    }
    .header-logo p {
        color: #ddd;
        font-size: 12px;
        margin: 5px 0 0;
    }
    .box {
        background: #fff;
        padding: 40px 30px;
        border-radius: 20px;
        width: 90%;
        max-width: 380px;
        box-shadow: 0 15px 35px rgba(0,0,0,0.2);
    }
    h2 {
        text-align: center;
        margin-bottom: 30px;
        color: #333;
        font-size: 24px;
        font-weight: bold;
    }
    input {
        width: 100%;
        padding: 14px 15px;
        margin-top: 15px;
        border: 1px solid #e2e8f0;
        border-radius: 10px;
        box-sizing: border-box;
        outline: none;
        background: #f8fafc;
        font-size: 15px;
        transition: 0.3s;
    }
    input:focus { border-color: #3a7afe; background: #fff; }
    
    .rem-box {
        display: flex;
        align-items: center;
        gap: 8px;
        margin-top: 20px;
        font-size: 14px;
        color: #64748b;
        cursor: pointer;
    }
    .rem-box input[type="checkbox"] {
        width: 20px; height: 20px; margin: 0; cursor: pointer;
    }
    
    button {
        background: #5c7cfa;
        color: #fff;
        border: 0;
        padding: 15px;
        width: 100%;
        border-radius: 10px;
        font-weight: bold;
        font-size: 16px;
        cursor: pointer;
        margin-top: 25px;
        box-shadow: 0 4px 12px rgba(92, 124, 250, 0.3);
        transition: 0.3s;
    }
    button:hover { background: #4763e4; transform: translateY(-1px); }
    
    .msg {
        background: #fee2e2;
        color: #b91c1c;
        padding: 12px;
        border-radius: 10px;
        margin-bottom: 20px;
        text-align: center;
        font-size: 14px;
        border: 1px solid #fecaca;
    }
    .toggle-text {
        text-align: center;
        margin-top: 25px;
        font-size: 14px;
        color: #333;
    }
    .toggle-text b { color: #3a7afe; cursor: pointer; }
    .reg-only { display: none; }
</style>
</head>
<body>

<div class="header-logo">
    <img src="https://mycsingtrade.com/assets/images/logoq.png" alt="Logo">
    <h1>MYCSINGTRADE</h1>
    <p>GLOBAL COMMERCE, FUTURE FORWARD</p>
</div>

<div class="box">
    <h2 id="title">ĐĂNG NHẬP</h2>

    <?php if($msg): ?>
        <div class="msg"><?=htmlspecialchars($msg)?></div>
    <?php endif; ?>

    <form method="post" id="mainForm">
        <div class="reg-only">
            <input name="fullname" placeholder="Họ và tên">
            <input name="phone" placeholder="Số điện thoại">
        </div>

        <input name="u" placeholder="Tên đăng nhập" value="<?=htmlspecialchars($remember_user)?>" required>
        <input type="password" name="p" placeholder="Mật khẩu" value="<?=htmlspecialchars($remember_pass)?>" required>

        <div class="reg-only">
            <input type="password" name="p2" placeholder="Nhập lại mật khẩu">
            <label class="rem-box" style="margin-top:15px; font-size:12px;">
                <input type="checkbox" id="agree" checked>
                Tôi đồng ý với<a href="#" style="color:#3a7afe; text-decoration:none;">Điều khoản dịch vụ</a>
            </label>
        </div>

        <label class="rem-box" id="rem-label">
            <input type="checkbox" name="remember" <?= $remember_user ? 'checked' : '' ?>>
            Ghi nhớ mật khẩu
        </label>

        <input type="hidden" name="action" id="action" value="login">
        <button type="submit" id="btn">ĐĂNG NHẬP</button>
    </form>

    <p class="toggle-text">
        <span id="text">Chưa có tài khoản?</span> 
        <b id="link" onclick="toggle()">Đăng ký</b>
    </p>
</div>

<script>
function toggle(){
    const actionInput = document.getElementById('action');
    const isLogin = actionInput.value === 'login';
    
    document.querySelectorAll('.reg-only').forEach(e => e.style.display = isLogin ? 'block' : 'none');
    document.getElementById('rem-label').style.display = isLogin ? 'none' : 'flex';
    
    actionInput.value = isLogin ? 'reg' : 'login';
    document.getElementById('btn').innerText = isLogin ? 'ĐĂNG KÝ' : 'ĐĂNG NHẬP';
    document.getElementById('title').innerText = isLogin ? 'ĐĂNG KÝ' : 'ĐĂNG NHẬP';
    document.getElementById('text').innerText = isLogin ? 'Đã có tài khoản?' : 'Chưa có tài khoản?';
    document.getElementById('link').innerText = isLogin ? 'Đăng nhập' : 'Đăng ký';
}

document.getElementById('mainForm').addEventListener('submit', function(e){
    if(document.getElementById('action').value === 'reg' && !document.getElementById('agree').checked){
        e.preventDefault();
        alert("Bạn phải đồng ý với điều khoản dịch vụ!");
    }
});
</script>

</body>
</html>
