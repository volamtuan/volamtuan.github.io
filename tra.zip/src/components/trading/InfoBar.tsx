import React from 'react';
import { useTradingStore } from '../../store/useTradingStore';

export const InfoBar: React.FC = () => {
  const { session, currentUser: user } = useTradingStore();
  
  // Mock prediction logic based on time
  const getPrediction = () => {
    if (user?.role === 'admin') {
      // In real app this comes from API
      return session.timeLeft % 2 === 0 ? 'TĂNG (Lưới)' : 'GIẢM (Lưới)';
    }
    return '';
  };

  return (
    <div className="bg-bg px-4 py-2 text-[11px] flex justify-between items-center border-t border-border">
      <div>
        <div className="text-gray-400">ID: <b className="text-white text-sm">{session.id}</b></div>
        <div className="text-gray-500">{new Date().toLocaleDateString('vi-VN')}</div>
      </div>

      <div className="flex-1"></div>

      <div className="text-right">
        <div className="text-gray-400">Kết thúc:</div>
        <b className={`text-yellow text-sm ${session.timeLeft <= 10 ? 'animate-pulse text-red' : ''}`}>{session.timeLeft}s</b>
      </div>
    </div>
  );
};
