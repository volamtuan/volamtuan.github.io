import React, { useEffect } from 'react';
import { Header } from '../components/trading/Header';
import { Chart } from '../components/trading/Chart';
import { Controls } from '../components/trading/Controls';
import { InfoBar } from '../components/trading/InfoBar';
import { History } from '../components/trading/History';
import { BetConfirmation } from '../components/trading/BetConfirmation';
import { useTradingStore } from '../store/useTradingStore';

export const TradingPage: React.FC = () => {
  const { updateTimer } = useTradingStore();

  useEffect(() => {
    const interval = setInterval(() => {
      updateTimer();
    }, 1000);
    return () => clearInterval(interval);
  }, [updateTimer]);

  return (
    <div className="min-h-screen bg-bg text-white font-sans flex flex-col overflow-hidden">
      <Header />
      
      <div className="flex-1 flex flex-col relative">
        <Chart />
        
        <div className="mt-auto">
          <Controls />
          <InfoBar />
          <History />
        </div>
      </div>

      <BetConfirmation />
    </div>
  );
};
