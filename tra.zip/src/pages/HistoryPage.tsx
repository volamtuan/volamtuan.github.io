import React from 'react';
import { useNavigate } from 'react-router-dom';
import { History } from '../components/trading/History';

export const HistoryPage: React.FC = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-bg text-white font-sans flex flex-col">
      <div className="flex justify-between items-center p-4 border-b border-border bg-panel">
        <h1 className="text-xl font-bold text-blue">LỊCH SỬ GIAO DỊCH</h1>
        <button 
          onClick={() => navigate('/')}
          className="bg-panel border border-border px-4 py-2 rounded hover:bg-white/5 text-sm"
        >
          ← Về sàn
        </button>
      </div>

      <div className="flex-1 flex flex-col">
        <History className="flex-1 h-auto border-t-0" />
      </div>
    </div>
  );
};
