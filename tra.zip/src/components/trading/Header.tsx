import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useTradingStore } from '../../store/useTradingStore';

export const Header: React.FC = () => {
  const { currentUser: user, logout } = useTradingStore();
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const navigate = useNavigate();

  if (!user) return null;

  return (
    <div className="flex justify-between items-center px-4 py-3 bg-panel border-b border-border z-50 relative">
      <div>
        <div className="text-sm text-gray-400">TÊN ĐĂNG NHẬP: <b className="text-white uppercase">{user.username}</b></div>
        <div className="text-sm text-gray-400">VÍ ĐIỆN TỬ: <b className="text-yellow text-lg">{user.balance.toLocaleString()}</b></div>
      </div>
      
      <div className="text-2xl cursor-pointer select-none" onClick={() => setIsMenuOpen(!isMenuOpen)}>
        ☰
      </div>

      {isMenuOpen && (
        <div className="absolute top-[60px] right-[15px] bg-panel border border-border rounded-lg w-[180px] z-[1002] shadow-xl">
          <div className="p-3 border-b border-border cursor-pointer hover:bg-white/5" onClick={() => { setIsMenuOpen(false); navigate('/wallet'); }}>NẠP TIỀN</div>
          <div className="p-3 border-b border-border cursor-pointer hover:bg-white/5" onClick={() => { setIsMenuOpen(false); navigate('/history'); }}>LỊCH SỬ</div>
          {user.role === 'admin' && (
            <div className="p-3 text-green cursor-pointer hover:bg-white/5" onClick={() => { setIsMenuOpen(false); navigate('/admin'); }}>ADMIN PANEL</div>
          )}
          <div className="p-3 text-red cursor-pointer hover:bg-white/5" onClick={() => { setIsMenuOpen(false); logout(); }}>ĐĂNG XUẤT</div>
        </div>
      )}
    </div>
  );
};
