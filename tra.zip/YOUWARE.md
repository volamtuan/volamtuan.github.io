# YOUWARE.md

## Project Overview
This is a React-based Binary Option (BO) trading interface, migrated from a legacy PHP application. It provides a modern, responsive UI for trading simulation with mock data.

## Tech Stack
- **Frontend**: React 18, TypeScript, Vite
- **Styling**: Tailwind CSS (Custom color palette matching original design)
- **State Management**: Zustand (`src/store/useTradingStore.ts`)
- **Icons**: Lucide React (via `lucide-react` package if needed, currently using unicode/custom)
- **Chart**: TradingView Widget (via script injection)

## Key Components
- **TradingPage**: Main page orchestrating the layout.
- **AdminPage**: Admin dashboard for controlling session results, viewing user stats, managing transactions, and viewing all bets.
- **WalletPage**: User interface for requesting deposits and withdrawals.
- **Header**: User info and navigation menu.
- **Chart**: TradingView widget integration.
- **Controls**: Betting amount selection and Up/Down actions.
- **InfoBar**: Session timer, ID, and Admin predictions.
- **History**: Tabbed view showing global session results and personal betting history (Amount, Win/Loss).
- **BetConfirmation**: Modal for confirming bets.

## Development
- **Run Dev Server**: `npm run dev`
- **Build**: `npm run build`
- **Lint**: `npm run lint`

## Architecture Notes
- **Store**: `useTradingStore` handles all application state including user balance, current session timer, betting logic, history, admin controls, and transactions.
- **Mock Data**: Currently, all data (User, Session, History, Transactions) is mocked within the store.
- **Timer**: The session timer is driven by a `setInterval` in `TradingPage` calling `updateTimer` action in the store.
- **Admin Mode**: The default user is set to 'admin' role. Access Admin Panel via the menu.
- **User Management**: Admin can Add, Edit (Password/Role), Lock/Unlock, and Login as any user.
- **Balance Adjustment**: Admin can manually add/subtract balance for any user.
- **Theme Customization**: Admin can toggle between Light and Dark mode in the Admin Panel.
- **Forced Result**: Admin can set the result ('TĂNG'/'GIẢM') for the *next* session outcome.
- **Payout Ratio**: Admin can configure the payout percentage (default 90%) in the Admin Panel. This affects the win amount calculation and is displayed on the trading buttons.
- **Transactions**: Users can request Deposit/Withdraw in WalletPage. Admin approves/rejects in AdminPage.
- **API Integration**: Replace mock data in `useTradingStore` with real API calls (`/api/user`, `/api/bet`, `/api/history`, `/api/transactions`).
- **Auth**: Implement real authentication using Youbase or custom backend.
- **Real-time**: Use WebSockets for session synchronization instead of client-side timer.
