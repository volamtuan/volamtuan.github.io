<?php
require_once 'config.php';

if (!isset($_SESSION['uid'])) {
    header("Location: login.php");
    exit;
}

$user = getCurrentUser($db);
?>
<!DOCTYPE html>
<html lang="vi" class="dark">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sàn Giao Dịch BO</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://s3.tradingview.com/tv.js"></script>
    <script>
        tailwind.config = {
            darkMode: 'class',
            theme: {
                extend: {
                    colors: {
                        bg: '#05070c',
                        panel: '#0c1220',
                        border: '#1f2f4a',
                        green: '#1adf90',
                        red: '#ff5b5b',
                        blue: '#3a7afe',
                        yellow: '#f5c542',
                    }
                }
            }
        }
    </script>
    <style>
        body { background-color: #05070c; color: white; }
        .dark body { background-color: #05070c; }
        .light body { background-color: #f0f2f5; color: #050505; }
    </style>
</head>
<body class="flex flex-col h-screen overflow-hidden font-sans">

    <!-- Header -->
    <div class="flex justify-between items-center px-4 py-3 bg-panel border-b border-border z-50 relative">
        <div>
            <div class="text-sm text-gray-400">TÊN ĐĂNG NHẬP: <b class="text-white uppercase"><?= htmlspecialchars($user['username']) ?></b></div>
            <div class="text-sm text-gray-400">VÍ ĐIỆN TỬ: <b class="text-yellow text-lg" id="balance"><?= number_format($user['balance']) ?></b></div>
        </div>
        <div class="flex items-center gap-4">
            <?php if($user['role'] === 'admin'): ?>
                <a href="admin.php" class="text-green font-bold text-sm">ADMIN PANEL</a>
            <?php endif; ?>
            <div class="text-2xl cursor-pointer select-none">☰</div>
        </div>
    </div>

    <!-- Chart -->
    <div class="flex-1 bg-black border-b border-[#1a2233] relative overflow-hidden min-h-[300px]">
        <div id="tvchart" class="w-full h-full absolute inset-0"></div>
    </div>

    <!-- Controls -->
    <div class="mt-auto">
        <div class="p-3 bg-panel">
            <div class="grid grid-cols-5 gap-1.5 mb-3">
                <?php 
                $amounts = [20000, 50000, 100000, 200000, 500000, 1000000, 2000000, 5000000, 10000000, 20000000];
                foreach($amounts as $amt): ?>
                    <button onclick="addAmount(<?= $amt ?>)" class="bg-[#0d1422] border border-border rounded-lg py-2.5 text-white text-xs hover:bg-[#1a253a] active:scale-95 transition-transform">
                        <?= number_format($amt/1000) . ($amt >= 1000000 ? 'M' : 'K') ?>
                    </button>
                <?php endforeach; ?>
                <button onclick="resetAmount()" class="bg-[#1f2f4a] border border-border rounded-lg py-2.5 text-red font-bold text-xs hover:bg-[#2a3f60] active:scale-95 transition-transform">XOÁ</button>
            </div>

            <div class="flex gap-2.5 mt-2.5">
                <button onclick="placeBet('TĂNG')" class="flex-1 bg-green text-black border-none rounded-xl py-4 font-extrabold text-base cursor-pointer active:scale-95 transition-transform shadow-lg shadow-green/20">
                    TĂNG 90%
                </button>
                <div class="flex-1 text-center flex items-center justify-center border border-border rounded-xl font-bold text-yellow bg-[#070b14] text-lg" id="betAmount">0</div>
                <button onclick="placeBet('GIẢM')" class="flex-1 bg-red text-white border-none rounded-xl py-4 font-extrabold text-base cursor-pointer active:scale-95 transition-transform shadow-lg shadow-red/20">
                    GIẢM 90%
                </button>
            </div>
        </div>

        <!-- Info Bar -->
        <div class="bg-bg px-4 py-2 text-[11px] flex justify-between items-center border-t border-border">
            <div>
                <div class="text-gray-400">ID: <b class="text-white text-sm" id="sessionId">...</b></div>
                <div class="text-gray-500"><?= date('d/m/Y') ?></div>
            </div>
            <div class="text-right">
                <div class="text-gray-400">Kết thúc:</div>
                <b class="text-yellow text-sm" id="timer">...</b>
            </div>
        </div>

        <!-- History -->
        <div class="bg-bg border-t border-border flex flex-col h-[160px] overflow-y-auto p-4" id="historyList">
            <!-- History items will be loaded here -->
        </div>
    </div>

    <script>
        // Init Chart
        new TradingView.widget({
            container_id: "tvchart", autosize: true, symbol: "BINANCE:BTCUSDT",
            interval: "1", theme: "dark", locale: "vi", hide_top_toolbar: true, hide_legend: true
        });

        let currentAmount = 0;
        
        function addAmount(val) {
            currentAmount += val;
            document.getElementById('betAmount').innerText = currentAmount.toLocaleString();
        }

        function resetAmount() {
            currentAmount = 0;
            document.getElementById('betAmount').innerText = "0";
        }

        async function placeBet(type) {
            if(currentAmount <= 0) return alert('Vui lòng chọn tiền cược');
            
            const res = await fetch('api.php?action=bet', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({ type, amount: currentAmount })
            });
            const data = await res.json();
            if(data.success) {
                alert('Đã đặt lệnh thành công!');
                resetAmount();
                updateData();
            } else {
                alert(data.message);
            }
        }

        async function updateData() {
            const res = await fetch('api.php?action=status');
            const data = await res.json();
            
            document.getElementById('sessionId').innerText = data.session_id;
            document.getElementById('timer').innerText = data.time_left + 's';
            document.getElementById('balance').innerText = parseInt(data.balance).toLocaleString();
            
            // Render History
            const historyHtml = data.history.map((h, idx) => `
                <div class="flex justify-between items-center py-1 border-b border-[#111]">
                    <div>
                        <span class="text-gray-400 text-xs">#${h.session_id}</span>
                        ${idx === 0 ? '<span class="bg-blue/20 text-blue text-[9px] px-1 rounded ml-1">MỚI</span>' : ''}
                    </div>
                    <span class="font-bold text-xs ${h.result === 'TĂNG' ? 'text-green' : 'text-red'}">${h.result}</span>
                </div>
            `).join('');
            document.getElementById('historyList').innerHTML = historyHtml;

            // Check Win
            if(data.win_amount > 0) {
                alert(`Thắng Cược +${data.win_amount.toLocaleString()} đ`);
            }
        }

        setInterval(updateData, 1000);
        updateData();
    </script>
</body>
</html>
