import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useTradingStore } from '../store/useTradingStore';
import { clsx } from 'clsx';

export const AdminPage: React.FC = () => {
  const navigate = useNavigate();
  const { 
    session, forcedResult, setAdminResult, currentUser, users, transactions, 
    adminApproveTransaction, adminRejectTransaction, allBets, adminAdjustBalance, 
    payoutPercent, setPayoutPercent, adminAddUser, adminUpdateUser, adminToggleLockUser, adminLoginAsUser,
    theme, toggleTheme
  } = useTradingStore();
  
  const [activeTab, setActiveTab] = useState<'CONTROL' | 'TRANSACTIONS' | 'BETS' | 'USERS'>('CONTROL');
  
  // User Management State
  const [isUserModalOpen, setIsUserModalOpen] = useState(false);
  const [editingUser, setEditingUser] = useState<string | null>(null);
  const [userForm, setUserForm] = useState({ username: '', password: '', balance: 0, role: 'user' as 'user' | 'admin' });

  if (!currentUser) return null;

  if (currentUser.role !== 'admin') {
    return (
      <div className="min-h-screen bg-bg text-white flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-red mb-4">Truy cập bị từ chối</h1>
          <button onClick={() => navigate('/')} className="bg-blue px-4 py-2 rounded">Về trang chủ</button>
        </div>
      </div>
    );
  }

  const handleSaveUser = () => {
    if (!userForm.username || !userForm.password) return alert('Vui lòng nhập đủ thông tin');
    
    if (editingUser) {
      adminUpdateUser(editingUser, userForm);
    } else {
      adminAddUser({ ...userForm, balance: Number(userForm.balance) });
    }
    setIsUserModalOpen(false);
    setEditingUser(null);
    setUserForm({ username: '', password: '', balance: 0, role: 'user' });
  };

  const openEditUser = (u: any) => {
    setEditingUser(u.username);
    setUserForm({ username: u.username, password: u.password || '', balance: u.balance, role: u.role });
    setIsUserModalOpen(true);
  };

  return (
    <div className="min-h-screen bg-bg text-white font-sans p-4">
      <div className="flex justify-between items-center mb-6 border-b border-border pb-4">
        <h1 className="text-xl font-bold text-yellow">ADMIN PANEL</h1>
        <div className="flex items-center gap-4">
          <button 
            onClick={toggleTheme}
            className="bg-panel border border-border px-3 py-1.5 rounded text-xs font-bold hover:bg-white/5"
          >
            {theme === 'dark' ? '☀️ Light Mode' : '🌙 Dark Mode'}
          </button>
          <div className="text-sm text-gray-400">
            Đang đăng nhập: <b className="text-blue">{currentUser.username}</b>
          </div>
          <button 
            onClick={() => navigate('/')}
            className="bg-panel border border-border px-4 py-2 rounded hover:bg-white/5"
          >
            ← Về sàn giao dịch
          </button>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-2 mb-6 overflow-x-auto pb-2">
        {[
          { id: 'CONTROL', label: 'Điều khiển' },
          { id: 'TRANSACTIONS', label: 'Duyệt Nạp/Rút' },
          { id: 'BETS', label: 'Lịch sử cược' },
          { id: 'USERS', label: 'Người dùng' },
        ].map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as any)}
            className={clsx(
              "px-4 py-2 rounded-lg font-bold text-sm whitespace-nowrap transition-colors",
              activeTab === tab.id ? "bg-blue text-white" : "bg-panel text-gray-400 hover:text-white"
            )}
          >
            {tab.label}
          </button>
        ))}
      </div>

      <div className="max-w-4xl mx-auto">
        {activeTab === 'CONTROL' && (
          <div className="bg-panel border border-border rounded-xl p-6">
            <h2 className="text-lg font-bold mb-4 text-blue">Điều chỉnh kết quả phiên #{session.id}</h2>
            
            <div className="flex items-center justify-between mb-6 bg-bg p-4 rounded-lg">
              <div>
                <div className="text-gray-400 text-sm">Thời gian còn lại</div>
                <div className="text-2xl font-bold text-yellow">{session.timeLeft}s</div>
              </div>
              <div className="text-right">
                <div className="text-gray-400 text-sm">Trạng thái</div>
                <div className="font-bold text-green">Đang diễn ra</div>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <button
                onClick={() => setAdminResult('TĂNG')}
                className={clsx(
                  "py-4 rounded-xl font-bold text-lg transition-all border-2",
                  forcedResult === 'TĂNG' 
                    ? "bg-green text-black border-white shadow-[0_0_15px_rgba(26,223,144,0.5)]" 
                    : "bg-[#0d1422] text-green border-green/30 hover:bg-green/10"
                )}
              >
                SET TĂNG
              </button>
              <button
                onClick={() => setAdminResult('GIẢM')}
                className={clsx(
                  "py-4 rounded-xl font-bold text-lg transition-all border-2",
                  forcedResult === 'GIẢM' 
                    ? "bg-red text-white border-white shadow-[0_0_15px_rgba(255,91,91,0.5)]" 
                    : "bg-[#0d1422] text-red border-red/30 hover:bg-red/10"
                )}
              >
                SET GIẢM
              </button>
            </div>
            
            {forcedResult && (
              <div className="mt-4 text-center">
                <span className="text-gray-400">Kết quả đã set: </span>
                <span className={clsx("font-bold", forcedResult === 'TĂNG' ? 'text-green' : 'text-red')}>
                  {forcedResult}
                </span>
                <button 
                  onClick={() => setAdminResult(null)}
                  className="ml-4 text-xs text-gray-500 underline hover:text-white"
                >
                  Huỷ
                </button>
              </div>
            )}

            <div className="mt-8 pt-6 border-t border-border">
              <h3 className="text-md font-bold mb-4 text-gray-300">Cấu hình hệ thống</h3>
              <div className="flex items-center justify-between bg-bg p-4 rounded-lg">
                <div className="text-gray-400 text-sm">Tỉ lệ trả thưởng (%)</div>
                <div className="flex items-center gap-2">
                  <input 
                    type="number" 
                    value={payoutPercent}
                    onChange={(e) => setPayoutPercent(Number(e.target.value))}
                    className="bg-panel border border-border rounded px-2 py-1 w-20 text-center text-yellow font-bold focus:outline-none focus:border-blue"
                  />
                  <span className="text-gray-500">%</span>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'TRANSACTIONS' && (
          <div className="bg-panel border border-border rounded-xl p-6">
            <h2 className="text-lg font-bold mb-4 text-gray-300">Yêu cầu Nạp/Rút</h2>
            <div className="flex flex-col gap-3">
              {transactions.length === 0 ? (
                <div className="text-center text-gray-500 py-8">Không có yêu cầu nào</div>
              ) : (
                transactions.map((tx) => (
                  <div key={tx.id} className="flex justify-between items-center bg-bg p-3 rounded-lg border border-border">
                    <div>
                      <div className="font-bold text-sm">
                        <span className="text-blue">{tx.username}</span>
                        <span className="mx-2 text-gray-600">|</span>
                        <span className={tx.type === 'DEPOSIT' ? 'text-green' : 'text-red'}>
                          {tx.type === 'DEPOSIT' ? 'Nạp tiền' : 'Rút tiền'}
                        </span>
                      </div>
                      <div className="text-xs text-gray-500">{new Date(tx.timestamp).toLocaleString()}</div>
                    </div>
                    <div className="flex items-center gap-4">
                      <div className="font-bold text-lg">{tx.amount.toLocaleString()}</div>
                      {tx.status === 'PENDING' ? (
                        <div className="flex gap-2">
                          <button 
                            onClick={() => adminApproveTransaction(tx.id)}
                            className="bg-green text-black text-xs font-bold px-3 py-1.5 rounded hover:bg-green/90"
                          >
                            DUYỆT
                          </button>
                          <button 
                            onClick={() => adminRejectTransaction(tx.id)}
                            className="bg-red text-white text-xs font-bold px-3 py-1.5 rounded hover:bg-red/90"
                          >
                            HUỶ
                          </button>
                        </div>
                      ) : (
                        <span className={clsx(
                          "text-xs font-bold px-2 py-1 rounded",
                          tx.status === 'APPROVED' ? 'bg-green/20 text-green' : 'bg-red/20 text-red'
                        )}>
                          {tx.status === 'APPROVED' ? 'Đã duyệt' : 'Đã huỷ'}
                        </span>
                      )}
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        )}

        {activeTab === 'BETS' && (
          <div className="bg-panel border border-border rounded-xl p-6">
            <h2 className="text-lg font-bold mb-4 text-gray-300">Lịch sử đặt cược toàn sàn</h2>
            <div className="overflow-x-auto">
              <table className="w-full text-sm text-left">
                <thead className="text-gray-500 border-b border-border">
                  <tr>
                    <th className="py-2">Phiên</th>
                    <th className="py-2">User</th>
                    <th className="py-2">Lệnh</th>
                    <th className="py-2">Số tiền</th>
                    <th className="py-2">Kết quả</th>
                  </tr>
                </thead>
                <tbody>
                  {allBets.length === 0 ? (
                    <tr><td colSpan={5} className="text-center py-4 text-gray-500">Chưa có dữ liệu</td></tr>
                  ) : (
                    allBets.map((bet, idx) => (
                      <tr key={idx} className="border-b border-border/50">
                        <td className="py-2 text-gray-400">#{bet.session_id}</td>
                        <td className="py-2 font-bold text-blue">{bet.username}</td>
                        <td className="py-2">
                          <span className={clsx("font-bold px-2 py-0.5 rounded text-xs", bet.betType === 'TĂNG' ? 'bg-green/10 text-green' : 'bg-red/10 text-red')}>
                            {bet.betType}
                          </span>
                        </td>
                        <td className="py-2">{bet.betAmount.toLocaleString()}</td>
                        <td className="py-2">
                          {bet.result === 'PENDING' ? (
                            <span className="text-yellow text-xs">Đang chờ</span>
                          ) : (
                            <span className={clsx("font-bold", bet.winAmount > 0 ? 'text-green' : 'text-gray-500')}>
                              {bet.winAmount > 0 ? `+${bet.winAmount.toLocaleString()}` : 'THUA'}
                            </span>
                          )}
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {activeTab === 'USERS' && (
          <div className="bg-panel border border-border rounded-xl p-6">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-lg font-bold text-gray-300">Quản lý người dùng</h2>
              <button 
                onClick={() => { setEditingUser(null); setUserForm({ username: '', password: '', balance: 0, role: 'user' }); setIsUserModalOpen(true); }}
                className="bg-blue text-white px-3 py-1.5 rounded text-sm font-bold hover:bg-blue/90"
              >
                + Thêm User
              </button>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-sm text-left">
                <thead className="text-gray-500 border-b border-border">
                  <tr>
                    <th className="py-2">Username</th>
                    <th className="py-2">Số dư</th>
                    <th className="py-2">Role</th>
                    <th className="py-2">Trạng thái</th>
                    <th className="py-2">Hành động</th>
                  </tr>
                </thead>
                <tbody>
                  {users.map((u) => (
                    <tr key={u.username} className="border-b border-border/50">
                      <td className="py-3 font-bold text-blue">{u.username}</td>
                      <td className="py-3 text-yellow">{u.balance.toLocaleString()}</td>
                      <td className="py-3 text-gray-400">{u.role}</td>
                      <td className="py-3">
                        <span className={clsx("text-xs px-2 py-0.5 rounded", u.isLocked ? "bg-red/20 text-red" : "bg-green/20 text-green")}>
                          {u.isLocked ? 'Locked' : 'Active'}
                        </span>
                      </td>
                      <td className="py-3 flex gap-2 flex-wrap">
                        <button onClick={() => openEditUser(u)} className="bg-gray-700 px-2 py-1 rounded text-xs hover:bg-gray-600">Sửa</button>
                        <button onClick={() => adminAdjustBalance(u.username, 1000000)} className="bg-green/20 text-green px-2 py-1 rounded text-xs hover:bg-green/30">+1M</button>
                        <button onClick={() => adminAdjustBalance(u.username, -1000000)} className="bg-red/20 text-red px-2 py-1 rounded text-xs hover:bg-red/30">-1M</button>
                        <button onClick={() => adminToggleLockUser(u.username)} className="bg-yellow/20 text-yellow px-2 py-1 rounded text-xs hover:bg-yellow/30">
                          {u.isLocked ? 'Mở khoá' : 'Khoá'}
                        </button>
                        {u.username !== currentUser.username && (
                          <button onClick={() => adminLoginAsUser(u.username)} className="bg-blue/20 text-blue px-2 py-1 rounded text-xs hover:bg-blue/30">Truy cập</button>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>

      {/* User Modal */}
      {isUserModalOpen && (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50">
          <div className="bg-panel border border-border rounded-xl p-6 w-full max-w-md">
            <h3 className="text-lg font-bold mb-4">{editingUser ? 'Sửa thông tin User' : 'Thêm User mới'}</h3>
            <div className="flex flex-col gap-3">
              <div>
                <label className="text-xs text-gray-400 block mb-1">Username</label>
                <input 
                  disabled={!!editingUser}
                  value={userForm.username}
                  onChange={e => setUserForm({...userForm, username: e.target.value})}
                  className="w-full bg-bg border border-border rounded p-2 text-white disabled:opacity-50"
                />
              </div>
              <div>
                <label className="text-xs text-gray-400 block mb-1">Mật khẩu</label>
                <input 
                  value={userForm.password}
                  onChange={e => setUserForm({...userForm, password: e.target.value})}
                  className="w-full bg-bg border border-border rounded p-2 text-white"
                />
              </div>
              <div>
                <label className="text-xs text-gray-400 block mb-1">Số dư ban đầu</label>
                <input 
                  type="number"
                  value={userForm.balance}
                  onChange={e => setUserForm({...userForm, balance: Number(e.target.value)})}
                  className="w-full bg-bg border border-border rounded p-2 text-white"
                />
              </div>
              <div>
                <label className="text-xs text-gray-400 block mb-1">Role</label>
                <select 
                  value={userForm.role}
                  onChange={e => setUserForm({...userForm, role: e.target.value as any})}
                  className="w-full bg-bg border border-border rounded p-2 text-white"
                >
                  <option value="user">User</option>
                  <option value="admin">Admin</option>
                </select>
              </div>
              <div className="flex gap-3 mt-4">
                <button onClick={handleSaveUser} className="flex-1 bg-blue py-2 rounded font-bold hover:bg-blue/90">Lưu</button>
                <button onClick={() => setIsUserModalOpen(false)} className="flex-1 bg-gray-700 py-2 rounded font-bold hover:bg-gray-600">Huỷ</button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
