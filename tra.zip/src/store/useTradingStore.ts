import { create } from 'zustand';
import { toast } from 'sonner';

interface User {
  username: string;
  balance: number;
  role: 'user' | 'admin';
  isLocked?: boolean;
  password?: string; // Mock password
  fullname?: string;
  phone?: string;
}

interface HistoryItem {
  session_id: number;
  result: 'TĂNG' | 'GIẢM';
  timestamp: number;
}

interface BetRecord {
  session_id: number;
  betType: 'TĂNG' | 'GIẢM';
  betAmount: number;
  winAmount: number;
  result: 'TĂNG' | 'GIẢM' | 'PENDING';
  timestamp: number;
  username?: string; // For admin view
}

interface Transaction {
  id: number;
  type: 'DEPOSIT' | 'WITHDRAW';
  amount: number;
  status: 'PENDING' | 'APPROVED' | 'REJECTED';
  timestamp: number;
  username: string;
}

interface TradingState {
  currentUser: User | null;
  isAuthenticated: boolean;
  users: User[]; // List of all users
  session: {
    id: number;
    timeLeft: number;
  };
  lastMinute: number; // Internal tracker for session change
  history: HistoryItem[];
  myBets: BetRecord[];
  allBets: BetRecord[]; // Global bets for admin
  transactions: Transaction[]; // Mock transactions
  currentBetAmount: number;
  pendingBet: { type: 'TĂNG' | 'GIẢM'; amount: number } | null;
  forcedResult: 'TĂNG' | 'GIẢM' | null;
  payoutPercent: number; // Default 90%
  theme: 'dark' | 'light';
  
  // Actions
  login: (u: string, p: string) => boolean;
  register: (u: string, p: string, fullname: string, phone: string) => boolean;
  logout: () => void;
  
  addAmount: (amount: number) => void;
  resetBetAmount: () => void;
  setPendingBet: (type: 'TĂNG' | 'GIẢM') => void;
  cancelPendingBet: () => void;
  confirmBet: () => void;
  updateTimer: () => void;
  setAdminResult: (result: 'TĂNG' | 'GIẢM' | null) => void;
  setPayoutPercent: (percent: number) => void;
  toggleTheme: () => void;
  requestTransaction: (type: 'DEPOSIT' | 'WITHDRAW', amount: number) => void;
  adminApproveTransaction: (id: number) => void;
  adminRejectTransaction: (id: number) => void;
  adminAdjustBalance: (username: string, amount: number) => void;
  
  // User Management Actions
  adminAddUser: (user: User) => void;
  adminUpdateUser: (username: string, data: Partial<User>) => void;
  adminToggleLockUser: (username: string) => void;
  adminLoginAsUser: (username: string) => void;
}

// Mock initial history
const generateMockHistory = (count: number, startId: number) => {
  return Array.from({ length: count }).map((_, i) => ({
    session_id: startId - i - 1,
    result: Math.random() > 0.5 ? 'TĂNG' : 'GIẢM' as 'TĂNG' | 'GIẢM',
    timestamp: Date.now() - (i + 1) * 60000,
  }));
};

const INITIAL_USERS: User[] = [
  { username: 'admin', balance: 1000000000, role: 'admin', password: '123' },
  { username: 'demo123', balance: 100000000, role: 'user', password: '123' },
  { username: 'vip_member', balance: 500000000, role: 'user', password: '123' },
];

export const useTradingStore = create<TradingState>((set, get) => ({
  currentUser: null,
  isAuthenticated: false,
  users: INITIAL_USERS,
  session: {
    id: 123, // Start from 123 as requested
    timeLeft: 60 - (Math.floor(Date.now() / 1000) % 60),
  },
  lastMinute: Math.floor(Date.now() / 60000),
  history: generateMockHistory(5, 123),
  myBets: [],
  allBets: [],
  transactions: [],
  currentBetAmount: 0,
  pendingBet: null,
  forcedResult: null,
  payoutPercent: 90,
  theme: 'dark',

  login: (u, p) => {
    const { users } = get();
    const user = users.find(user => user.username === u && user.password === p);
    if (user) {
      if (user.isLocked) {
        toast.error('Tài khoản đã bị khoá!');
        return false;
      }
      set({ currentUser: user, isAuthenticated: true });
      toast.success('Đăng nhập thành công!');
      return true;
    }
    toast.error('Sai tên đăng nhập hoặc mật khẩu!');
    return false;
  },

  register: (u, p, fullname, phone) => {
    const { users } = get();
    if (users.find(user => user.username === u)) {
      toast.error('Tên đăng nhập đã tồn tại!');
      return false;
    }
    const newUser: User = {
      username: u,
      password: p,
      fullname,
      phone,
      balance: 0, // New users start with 0
      role: 'user'
    };
    set({ users: [...users, newUser] });
    toast.success('Đăng ký thành công! Vui lòng đăng nhập.');
    return true;
  },

  logout: () => {
    set({ currentUser: null, isAuthenticated: false });
    toast.info('Đã đăng xuất');
  },

  addAmount: (amount) => set((state) => ({ currentBetAmount: state.currentBetAmount + amount })),
  
  resetBetAmount: () => set({ currentBetAmount: 0 }),
  
  toggleTheme: () => set((state) => ({ theme: state.theme === 'dark' ? 'light' : 'dark' })),

  setPendingBet: (type) => {
    const { currentBetAmount, currentUser } = get();
    if (!currentUser) return;
    
    if (currentBetAmount <= 0) {
      toast.error('Vui lòng chọn số tiền cược!');
      return;
    }
    if (currentBetAmount > currentUser.balance) {
      toast.error('Số dư không đủ!');
      return;
    }
    if (currentUser.isLocked) {
      toast.error('Tài khoản của bạn đã bị khoá!');
      return;
    }
    set({ pendingBet: { type, amount: currentBetAmount } });
  },

  cancelPendingBet: () => set({ pendingBet: null }),

  confirmBet: () => {
    const { pendingBet, currentUser, session } = get();
    if (!pendingBet || !currentUser) return;

    const newBet: BetRecord = {
      session_id: session.id,
      betType: pendingBet.type,
      betAmount: pendingBet.amount,
      winAmount: 0,
      result: 'PENDING',
      timestamp: Date.now(),
      username: currentUser.username,
    };

    set((state) => {
      if (!state.currentUser) return state;
      const newBalance = state.currentUser.balance - pendingBet.amount;
      // Update both currentUser and the user in the list
      const updatedUsers = state.users.map(u => 
        u.username === state.currentUser!.username ? { ...u, balance: newBalance } : u
      );
      
      return {
        currentUser: { ...state.currentUser, balance: newBalance },
        users: updatedUsers,
        myBets: [newBet, ...state.myBets],
        allBets: [newBet, ...state.allBets],
        pendingBet: null,
        currentBetAmount: 0,
      };
    });
    toast.success('Đặt cược thành công!');
  },

  updateTimer: () => {
    set((state) => {
      const now = Date.now();
      const currentMinute = Math.floor(now / 60000);
      const seconds = Math.floor(now / 1000) % 60;
      const timeLeft = 60 - seconds;

      // New session logic
      if (currentMinute > state.lastMinute) {
        // Process results for the ENDED session (state.session.id)
        const endedSessionId = state.session.id;
        
        // Determine result
        let finalResult: 'TĂNG' | 'GIẢM' = Math.random() > 0.5 ? 'TĂNG' : 'GIẢM';
        if (state.forcedResult) {
          finalResult = state.forcedResult;
        }

        // Calculate winnings
        const updatedMyBets = state.myBets.map(bet => {
          if (bet.session_id === endedSessionId && bet.result === 'PENDING') {
            const isWin = bet.betType === finalResult;
            const winAmount = isWin ? bet.betAmount * (1 + state.payoutPercent / 100) : 0;
            return { ...bet, result: finalResult, winAmount };
          }
          return bet;
        });

        // Update balances for winners
        let updatedCurrentUser = state.currentUser;
        let updatedUsers = [...state.users];

        updatedMyBets.forEach(bet => {
          if (bet.session_id === endedSessionId && bet.winAmount > 0) {
            // Update global users list
            updatedUsers = updatedUsers.map(u => {
              if (u.username === bet.username) {
                return { ...u, balance: u.balance + bet.winAmount };
              }
              return u;
            });

            // Update current user if it's them
            if (updatedCurrentUser && bet.username === updatedCurrentUser.username) {
              updatedCurrentUser = { ...updatedCurrentUser, balance: updatedCurrentUser.balance + bet.winAmount };
              toast.success(`Chúc mừng! Bạn đã thắng ${bet.winAmount.toLocaleString()} đ`);
            }
          }
        });

        // Add to history
        const newHistoryItem: HistoryItem = {
          session_id: endedSessionId,
          result: finalResult,
          timestamp: now,
        };

        return {
          session: { id: endedSessionId + 1, timeLeft },
          lastMinute: currentMinute,
          history: [newHistoryItem, ...state.history].slice(0, 50),
          myBets: updatedMyBets,
          currentUser: updatedCurrentUser,
          users: updatedUsers,
          forcedResult: null, // Reset forced result
        };
      }

      return {
        session: { ...state.session, timeLeft },
      };
    });
  },

  setAdminResult: (result) => set({ forcedResult: result }),
  setPayoutPercent: (percent) => set({ payoutPercent: percent }),

  requestTransaction: (type, amount) => {
    const { currentUser } = get();
    if (!currentUser) return;

    const newTx: Transaction = {
      id: Date.now(),
      type,
      amount,
      status: 'PENDING',
      timestamp: Date.now(),
      username: currentUser.username,
    };
    set((state) => ({ transactions: [newTx, ...state.transactions] }));
    toast.success('Đã gửi yêu cầu thành công!');
  },

  adminApproveTransaction: (id) => {
    set((state) => {
      const tx = state.transactions.find(t => t.id === id);
      if (!tx || tx.status !== 'PENDING') return state;

      let updatedUsers = [...state.users];
      let updatedCurrentUser = state.currentUser;

      if (tx.type === 'DEPOSIT') {
        updatedUsers = updatedUsers.map(u => 
          u.username === tx.username ? { ...u, balance: u.balance + tx.amount } : u
        );
        if (updatedCurrentUser && updatedCurrentUser.username === tx.username) {
          updatedCurrentUser = { ...updatedCurrentUser, balance: updatedCurrentUser.balance + tx.amount };
        }
      } else if (tx.type === 'WITHDRAW') {
        updatedUsers = updatedUsers.map(u => 
          u.username === tx.username ? { ...u, balance: u.balance - tx.amount } : u
        );
        if (updatedCurrentUser && updatedCurrentUser.username === tx.username) {
          updatedCurrentUser = { ...updatedCurrentUser, balance: updatedCurrentUser.balance - tx.amount };
        }
      }

      const updatedTransactions = state.transactions.map(t => 
        t.id === id ? { ...t, status: 'APPROVED' as const } : t
      );

      toast.success('Đã duyệt giao dịch!');
      return {
        transactions: updatedTransactions,
        users: updatedUsers,
        currentUser: updatedCurrentUser,
      };
    });
  },

  adminRejectTransaction: (id) => {
    set((state) => ({
      transactions: state.transactions.map(t => 
        t.id === id ? { ...t, status: 'REJECTED' as const } : t
      )
    }));
    toast.success('Đã từ chối giao dịch!');
  },

  adminAdjustBalance: (username, amount) => {
    set((state) => {
      const updatedUsers = state.users.map(u => 
        u.username === username ? { ...u, balance: u.balance + amount } : u
      );
      let updatedCurrentUser = state.currentUser;
      if (updatedCurrentUser && updatedCurrentUser.username === username) {
        updatedCurrentUser = { ...updatedCurrentUser, balance: updatedCurrentUser.balance + amount };
      }
      return { users: updatedUsers, currentUser: updatedCurrentUser };
    });
    toast.success('Đã cộng/trừ tiền thành công!');
  },

  adminAddUser: (user) => {
    set((state) => {
      if (state.users.find(u => u.username === user.username)) {
        toast.error('Tên đăng nhập đã tồn tại');
        return state;
      }
      return { users: [...state.users, user] };
    });
    toast.success('Đã thêm người dùng mới');
  },

  adminUpdateUser: (username, data) => {
    set((state) => {
      const updatedUsers = state.users.map(u => 
        u.username === username ? { ...u, ...data } : u
      );
      let updatedCurrentUser = state.currentUser;
      if (updatedCurrentUser && updatedCurrentUser.username === username) {
        updatedCurrentUser = { ...updatedCurrentUser, ...data };
      }
      return { users: updatedUsers, currentUser: updatedCurrentUser };
    });
    toast.success('Đã cập nhật thông tin');
  },

  adminToggleLockUser: (username) => {
    set((state) => {
      const updatedUsers = state.users.map(u => 
        u.username === username ? { ...u, isLocked: !u.isLocked } : u
      );
      let updatedCurrentUser = state.currentUser;
      if (updatedCurrentUser && updatedCurrentUser.username === username) {
        updatedCurrentUser = { ...updatedCurrentUser, isLocked: !updatedCurrentUser.isLocked };
      }
      return { users: updatedUsers, currentUser: updatedCurrentUser };
    });
    toast.success('Đã thay đổi trạng thái khoá');
  },

  adminLoginAsUser: (username) => {
    const { users } = get();
    const targetUser = users.find(u => u.username === username);
    if (targetUser) {
      set({ currentUser: targetUser, isAuthenticated: true });
      toast.success(`Đang đăng nhập với tư cách: ${username}`);
    }
  }
}));
