import React from 'react';
import { useTradingStore } from '../../store/useTradingStore';
import { clsx } from 'clsx';

const AMOUNTS = [
  { label: '20K', value: 20000 },
  { label: '50K', value: 50000 },
  { label: '100K', value: 100000 },
  { label: '200K', value: 200000 },
  { label: '500K', value: 500000 },
  { label: '1M', value: 1000000 },
  { label: '2M', value: 2000000 },
  { label: '5M', value: 5000000 },
  { label: '10M', value: 10000000 },
  { label: '20M', value: 20000000 },
  { label: '50M', value: 50000000 },
  { label: '100M', value: 100000000 },
  { label: '200M', value: 200000000 },
  { label: '500M', value: 500000000 },
];

export const Controls: React.FC = () => {
  const { addAmount, resetBetAmount, currentBetAmount, setPendingBet, payoutPercent } = useTradingStore();

  return (
    <div className="p-3 bg-panel">
      {/* Amount Buttons */}
      <div className="grid grid-cols-5 gap-1.5 mb-3">
        {AMOUNTS.map((amt) => (
          <button
            key={amt.value}
            onClick={() => addAmount(amt.value)}
            className="bg-[#0d1422] border border-border rounded-lg py-2.5 text-white text-xs hover:bg-[#1a253a] active:scale-95 transition-transform"
          >
            {amt.label}
          </button>
        ))}
        <button
          onClick={resetBetAmount}
          className="bg-[#1f2f4a] border border-border rounded-lg py-2.5 text-red font-bold text-xs hover:bg-[#2a3f60] active:scale-95 transition-transform"
        >
          XOÁ
        </button>
      </div>

      {/* Action Buttons */}
      <div className="flex gap-2.5 mt-2.5">
        <button
          onClick={() => setPendingBet('TĂNG')}
          className="flex-1 bg-green text-black border-none rounded-xl py-4 font-extrabold text-base cursor-pointer active:scale-95 transition-transform shadow-lg shadow-green/20"
        >
          TĂNG {payoutPercent}%
        </button>
        
        <div className="flex-1 text-center flex items-center justify-center border border-border rounded-xl font-bold text-yellow bg-[#070b14] text-lg">
          {currentBetAmount.toLocaleString()}
        </div>

        <button
          onClick={() => setPendingBet('GIẢM')}
          className="flex-1 bg-red text-white border-none rounded-xl py-4 font-extrabold text-base cursor-pointer active:scale-95 transition-transform shadow-lg shadow-red/20"
        >
          GIẢM {payoutPercent}%
        </button>
      </div>
    </div>
  );
};
