import React, { useState } from 'react';
import { useTradingStore } from '../../store/useTradingStore';
import { clsx } from 'clsx';

export const History: React.FC<{ className?: string }> = ({ className }) => {
  const { history, myBets } = useTradingStore();
  const [activeTab, setActiveTab] = useState<'RESULT' | 'MY_BETS'>('RESULT');

  return (
    <div className={clsx("bg-bg border-t border-border flex flex-col", className || "h-[160px]")}>
      {/* Tabs */}
      <div className="flex border-b border-border">
        <button
          onClick={() => setActiveTab('RESULT')}
          className={clsx(
            "flex-1 py-2 text-xs font-bold transition-colors",
            activeTab === 'RESULT' ? "text-white bg-panel border-b-2 border-blue" : "text-gray-500 hover:text-gray-300"
          )}
        >
          KẾT QUẢ
        </button>
        <button
          onClick={() => setActiveTab('MY_BETS')}
          className={clsx(
            "flex-1 py-2 text-xs font-bold transition-colors",
            activeTab === 'MY_BETS' ? "text-white bg-panel border-b-2 border-blue" : "text-gray-500 hover:text-gray-300"
          )}
        >
          LỊCH SỬ CƯỢC
        </button>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto p-4">
        {activeTab === 'RESULT' ? (
          <div className="flex flex-col gap-2">
            {history.map((h, index) => (
              <div key={h.session_id} className="flex justify-between items-center py-1 border-b border-[#111] last:border-0">
                <div>
                  <div className="text-gray-400 text-xs flex items-center gap-2">
                    #{h.session_id}
                    {index === 0 && <span className="bg-blue/20 text-blue text-[9px] px-1 rounded">MỚI</span>}
                  </div>
                  <div className="text-[10px] text-gray-600">
                    {h.timestamp ? new Date(h.timestamp).toLocaleTimeString() : ''}
                  </div>
                </div>
                <span className={clsx(
                  "font-bold text-xs",
                  h.result === 'TĂNG' ? 'text-green' : 'text-red'
                )}>
                  {h.result}
                </span>
              </div>
            ))}
          </div>
        ) : (
          <div className="flex flex-col gap-2">
            {myBets.length === 0 ? (
              <div className="text-center text-gray-500 text-xs py-4">Chưa có lệnh nào</div>
            ) : (
              myBets.map((bet, index) => (
                <div key={index} className="flex flex-col border-b border-[#111] last:border-0 py-2">
                  <div className="flex justify-between items-center mb-1">
                    <span className="text-gray-400 text-[10px]">#{bet.session_id}</span>
                    <span className="text-gray-500 text-[10px]">
                      {bet.timestamp ? new Date(bet.timestamp).toLocaleTimeString() : ''}
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <div className="flex items-center gap-2">
                      <span className={clsx(
                        "font-bold text-xs px-1.5 py-0.5 rounded",
                        bet.betType === 'TĂNG' ? 'bg-green/10 text-green' : 'bg-red/10 text-red'
                      )}>
                        {bet.betType}
                      </span>
                      <span className="text-white text-xs">{bet.betAmount.toLocaleString()}</span>
                    </div>
                    <div className="text-right">
                      {bet.result === 'PENDING' ? (
                        <span className="text-yellow text-xs font-bold">ĐANG CHỜ...</span>
                      ) : (
                        <span className={clsx(
                          "font-bold text-xs",
                          bet.winAmount > 0 ? 'text-green' : 'text-gray-500'
                        )}>
                          {bet.winAmount > 0 ? `+${bet.winAmount.toLocaleString()}` : '-0'}
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        )}
      </div>
    </div>
  );
};
